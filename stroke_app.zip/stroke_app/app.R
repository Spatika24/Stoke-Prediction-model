library(shiny)
library(readr)
library(dplyr)
library(tibble)
library(parsnip)
library(workflows)

# Load the final model
final_model <- readRDS("final_model.rds")

# Define UI
ui <- fluidPage(
  titlePanel("🧠 Stroke Risk Prediction"),
  
  sidebarLayout(
    sidebarPanel(
      numericInput("id", "Patient ID", value = 1, min = 1),
      selectInput("gender", "Gender", choices = c("Male", "Female", "Other")),
      numericInput("age", "Age", value = 40, min = 0, max = 120),
      selectInput("hypertension", "Hypertension", choices = c("No" = 0, "Yes" = 1)),
      selectInput("heart_disease", "Heart Disease", choices = c("No" = 0, "Yes" = 1)),
      selectInput("ever_married", "Ever Married", choices = c("No", "Yes")),
      selectInput("work_type", "Work Type", choices = c("Private", "Self-employed", "Govt_job", "children", "Never_worked")),
      selectInput("Residence_type", "Residence Type", choices = c("Urban", "Rural")),
      numericInput("avg_glucose_level", "Average Glucose Level", value = 100, min = 0),
      numericInput("bmi", "BMI", value = 25.0, min = 0, step = 0.1),
      selectInput("smoking_status", "Smoking Status", choices = c("formerly smoked", "never smoked", "smokes", "Unknown")),
      actionButton("predict_btn", "Predict")
    ),
    
    mainPanel(
      h3("Prediction Result:"),
      verbatimTextOutput("prediction")
    )
  )
)

# Define Server
server <- function(input, output) {
  observeEvent(input$predict_btn, {
    output$prediction <- renderText({
      # Validate numeric inputs
      bmi_val <- suppressWarnings(as.numeric(input$bmi))
      glucose_val <- suppressWarnings(as.numeric(input$avg_glucose_level))
      
      if (is.na(bmi_val) || is.na(glucose_val)) {
        return("❌ Please enter valid numeric values for BMI and Glucose Level.")
      }
      
      input_data <- tibble(
        id = as.numeric(input$id),
        gender = input$gender,
        age = as.numeric(input$age),
        hypertension = as.numeric(input$hypertension),
        heart_disease = as.numeric(input$heart_disease),
        ever_married = input$ever_married,
        work_type = input$work_type,
        Residence_type = input$Residence_type,
        avg_glucose_level = glucose_val,
        bmi = as.character(bmi_val),  
        smoking_status = input$smoking_status
      )
      
      
      # Predict
      pred <- predict(final_model, new_data = input_data, type = "prob")
      prob <- pred$.pred_1
      
      if (is.na(prob)) {
        return("⚠️ Prediction failed. Please check input values.")
      }
      
      if (prob >= 0.5) {
        paste0("⚠️ High risk of stroke (", round(prob * 100, 2), "%)")
      } else {
        paste0("✅ Low risk of stroke (", round(prob * 100, 2), "%)")
      }
    })
  })
}

# Run App
shinyApp(ui = ui, server = server)

